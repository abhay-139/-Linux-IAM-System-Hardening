#!/bin/bash
# fix_misconfigs.sh - helper fixes for common misconfigurations (run as root)
set -euo pipefail
echo "Fixing world-writable bits under /etc"
find /etc -xdev -type f -perm -0002 -print -exec chmod o-w {} \; || true
echo "Fix sudoers.d file permissions"
if [ -d /etc/sudoers.d ]; then
  find /etc/sudoers.d -type f -print -exec chmod 0440 {} \;
  chown root:root /etc/sudoers.d/* || true
fi
echo "Fix sensitive file permissions"
chmod 0644 /etc/passwd || true; chown root:root /etc/passwd || true
chmod 0640 /etc/shadow || true; chown root:shadow /etc/shadow || true
if [ -d /root/.ssh ]; then
  chmod 700 /root/.ssh || true
  if [ -f /root/.ssh/authorized_keys ]; then
    chmod 600 /root/.ssh/authorized_keys || true
    chown root:root /root/.ssh/authorized_keys || true
  fi
fi
echo "Validate sudoers with: visudo -c"
