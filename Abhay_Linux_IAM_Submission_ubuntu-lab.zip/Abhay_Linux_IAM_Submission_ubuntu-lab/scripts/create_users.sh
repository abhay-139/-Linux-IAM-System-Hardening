#!/bin/bash
# create_users.sh - idempotent user/group creation for lab policy
set -euo pipefail
groups=(admin devs auditors ops project project_readers)
for g in "${groups[@]}"; do
  if ! getent group "$g" >/dev/null; then
    groupadd "$g"
    echo "created group $g"
  else
    echo "group $g exists"
  fi
done
users=(
  "alice:/bin/bash:admin,project"
  "bob:/bin/bash:devs,project"
  "carol:/bin/bash:devs,project"
  "dave:/bin/bash:auditors,project_readers"
  "svc-deploy:/usr/sbin/nologin:ops"
)
for entry in "${users[@]}"; do
  IFS=":" read -r user shell groupcsv <<< "$entry"
  if id "$user" &>/dev/null; then
    echo "user $user exists"
  else
    useradd -m -s "$shell" -G "$(echo "$groupcsv" | tr ',' ',')" "$user"
    echo "created user $user"
    if [[ "$shell" == "/usr/sbin/nologin" || "$user" == svc-* ]]; then
      passwd -l "$user" || true
    else
      echo "Please set a password for $user (passwd $user)"
    fi
  fi
done
mkdir -p /srv/project
chown root:project /srv/project
chmod 2770 /srv/project
setfacl -m g:project_readers:rx /srv/project || true
echo "Done."
